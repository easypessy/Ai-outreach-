#!/usr/bin/env python3
"""
Scheduled outreach runner.

Finds leads (same pipeline as the live app), emails the ones with a public
address, checks the inbox for replies, and Gemini-classifies each reply as
interested / not — labelling interested ones "Hot Leads" in Gmail.

Runs from a GitHub Actions cron job, not from the Render app. State (who's
been contacted, who replied) lives in sent_log.json and is committed back
to the repo by the workflow after each run, so it survives even though the
free Render instance itself remembers nothing between sleeps.

Nothing here auto-sends DMs on any social platform — only email, which is
the one channel this can be done on without violating a platform's terms
of service.
"""
import email as email_lib
import imaplib
import json
import os
import smtplib
import ssl
import sys
import time
from email.mime.text import MIMEText

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import app as core  # reuse the exact lead-finding / pitch logic the live app uses

CONFIG_PATH = os.environ.get("CAMPAIGNS_PATH", "campaigns.json")
LOG_PATH = os.environ.get("SENT_LOG_PATH", "sent_log.json")

GMAIL_ADDRESS = os.environ.get("GMAIL_ADDRESS", "").strip()
GMAIL_APP_PASSWORD = os.environ.get("GMAIL_APP_PASSWORD", "").strip()
HOT_LABEL = os.environ.get("HOT_LABEL", "Hot Leads")
SEND_DELAY_SECONDS = int(os.environ.get("SEND_DELAY_SECONDS", "12"))
OPT_OUT_FOOTER = ("\n\n---\nDidn't mean to reach you, or not interested? "
                   "Just reply STOP and I won't follow up again.")


def load_json(path, default):
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    return default


def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def find_campaign_leads(camp):
    """Reuses app.py's real pipeline. Only returns leads with a public email —
    that's the one contact channel this script is allowed to message on its own."""
    city = (camp.get("city") or "").strip()
    radius = camp.get("radius", 5)
    desc = (camp.get("custom_service_description") or "").strip()
    category = (camp.get("category") or "").strip()

    geo = core.geocode(city)
    if not geo:
        print(f"  ! couldn't geocode city: {city!r}")
        return []

    cat_keys = []
    if category:
        cat_keys = [category]
    elif desc:
        try:
            matches = core.match_categories({"service_description": desc})
            cat_keys = [m["key"] for m in matches["matches"]]
        except Exception as e:
            print(f"  ! category matching failed: {e}")
            return []
    if not cat_keys:
        print("  ! campaign needs either 'category' or 'custom_service_description'")
        return []

    all_leads = []
    for cat_key in cat_keys:
        if cat_key not in core.CATEGORIES:
            print(f"  ! unknown category: {cat_key!r}")
            continue
        query = core.build_query(geo["lat"], geo["lon"], radius * 1000, core.CATEGORIES[cat_key]["filters"])
        try:
            data = core.overpass(query)
        except Exception as e:
            print(f"  ! Overpass failed for {cat_key}: {e}")
            continue
        raw = core.parse_elements(data.get("elements", []))[:40]
        for lead in raw:
            if not lead.get("email"):
                continue
            lead = dict(lead)
            lead["_category"] = cat_key
            lead["_city_display"] = geo["name"]
            all_leads.append(lead)

    return all_leads


def build_pitch_for_lead(camp, lead):
    desc = (camp.get("custom_service_description") or "").strip()
    service = (camp.get("service") or "").strip()
    cat_key = lead["_category"]
    city = lead["_city_display"]

    if service and service in core.SERVICES:
        subject = core.fill_pitch(core.SERVICES[service]["email_subject"], lead, service, cat_key, city)
        body = core.fill_pitch(core.SERVICES[service]["email_body"], lead, service, cat_key, city)
        return subject, body
    if desc:
        result = core.generate_custom_pitch({
            "service_description": desc,
            "city": city,
            "lead": {**lead, "category": cat_key},
        })
        return result["email_subject"], result["email_body"]
    return None, None


def send_email(to_addr, subject, body, sender_name):
    if not GMAIL_ADDRESS or not GMAIL_APP_PASSWORD:
        raise RuntimeError("GMAIL_ADDRESS / GMAIL_APP_PASSWORD not set")
    full_body = body.replace("[Your name]", sender_name) + OPT_OUT_FOOTER
    msg = MIMEText(full_body)
    msg["Subject"] = subject
    msg["From"] = f"{sender_name} <{GMAIL_ADDRESS}>"
    msg["To"] = to_addr
    ctx = ssl.create_default_context()
    with smtplib.SMTP("smtp.gmail.com", 587) as server:
        server.starttls(context=ctx)
        server.login(GMAIL_ADDRESS, GMAIL_APP_PASSWORD)
        server.sendmail(GMAIL_ADDRESS, [to_addr], msg.as_string())


def run_sending(config, log):
    sender_name = (config.get("sender_name") or "").strip()
    if not sender_name or sender_name.upper().startswith("REPLACE"):
        print("! sender_name not set in campaigns.json — refusing to send unsigned emails.")
        return
    total_sent = 0
    for camp in config.get("campaigns", []):
        cap = camp.get("daily_cap", 10)
        print(f"Campaign: {camp.get('label') or camp.get('city')}")
        leads = find_campaign_leads(camp)
        sent_this_campaign = 0
        for lead in leads:
            if sent_this_campaign >= cap:
                break
            key = lead["email"].strip().lower()
            if key in log:
                continue  # already contacted, replied, or opted out
            subject, body = build_pitch_for_lead(camp, lead)
            if not subject:
                continue
            try:
                send_email(lead["email"], subject, body, sender_name)
                log[key] = {
                    "name": lead["name"], "city": lead["_city_display"],
                    "category": lead["_category"], "sent_at": time.strftime("%Y-%m-%d"),
                    "subject": subject, "status": "sent",
                }
                sent_this_campaign += 1
                total_sent += 1
                print(f"  sent -> {lead['name']} <{lead['email']}>")
                time.sleep(SEND_DELAY_SECONDS)
            except Exception as e:
                print(f"  ! failed to send to {lead['email']}: {e}")
    print(f"Total sent this run: {total_sent}")


def _first_text_part(msg):
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/plain" and \
               part.get("Content-Disposition") is None:
                payload = part.get_payload(decode=True)
                if payload:
                    return payload.decode("utf-8", "ignore")
        return ""
    payload = msg.get_payload(decode=True)
    return payload.decode("utf-8", "ignore") if payload else ""


def check_replies(log):
    if not GMAIL_ADDRESS or not GMAIL_APP_PASSWORD:
        print("! Gmail creds not set — skipping reply check")
        return
    pending = {addr: rec for addr, rec in log.items() if rec.get("status") == "sent"}
    if not pending:
        print("No pending sends to check replies for.")
        return

    imap = imaplib.IMAP4_SSL("imap.gmail.com")
    imap.login(GMAIL_ADDRESS, GMAIL_APP_PASSWORD)
    imap.select("INBOX")

    for addr, rec in pending.items():
        typ, data = imap.uid("search", None, f'(FROM "{addr}")')
        uids = data[0].split() if typ == "OK" and data and data[0] else []
        if not uids:
            continue
        latest_uid = uids[-1]
        typ, msg_data = imap.uid("fetch", latest_uid, "(RFC822)")
        if typ != "OK" or not msg_data or not msg_data[0]:
            continue
        raw = msg_data[0][1]
        msg = email_lib.message_from_bytes(raw)
        body_text = _first_text_part(msg)[:1500]

        if "stop" in body_text.lower()[:200]:
            rec["status"] = "opted_out"
            print(f"  {addr}: opted out")
            continue

        try:
            verdict = core.gemini_json(
                "A cold-outreach email was sent to a local business. Here is their reply:\n\n"
                f'"{body_text}"\n\n'
                'Classify it. Reply with ONLY this JSON: '
                '{"interested": true, "reason": "short reason, max 12 words"}'
            )
        except Exception as e:
            print(f"  ! couldn't classify reply from {addr}: {e}")
            continue

        interested = bool(verdict.get("interested"))
        rec["status"] = "replied_interested" if interested else "replied_not_interested"
        rec["reply_reason"] = verdict.get("reason", "")
        print(f"  {addr}: {rec['status']} ({rec['reply_reason']})")

        if interested:
            try:
                imap.uid("store", latest_uid, "+X-GM-LABELS", f'("{HOT_LABEL}")')
            except Exception as e:
                print(f"  ! couldn't apply label for {addr}: {e}")

    imap.logout()


def main():
    config = load_json(CONFIG_PATH, {"sender_name": "", "campaigns": []})
    log = load_json(LOG_PATH, {})

    print("=== Checking replies ===")
    check_replies(log)
    save_json(LOG_PATH, log)

    print("=== Sending new pitches ===")
    run_sending(config, log)
    save_json(LOG_PATH, log)


if __name__ == "__main__":
    main()
